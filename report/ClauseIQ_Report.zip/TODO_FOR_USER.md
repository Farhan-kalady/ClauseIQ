# ClauseIQ Final Project Report — User Action Items (TODO)

This document lists items that require manual user input or optional environment customization.

---

## 1. User Interface Screenshots to Capture and Add

Because screenshots of the live interactive web browser interface cannot be captured headlessly by automated build tools, conditional placeholders (`\IfFileExists`) have been implemented in `chapters/ch06_model_deployment.tex`.

To display the live user interface in the compiled PDF report, capture the following screenshots from your local running frontend (`http://localhost:5173`) and place them in `report/figures/ui/` with the exact filenames listed below:

1. **`report/figures/ui/classify_text.png`**
   - **View:** Single Clause Text Classification.
   - **What to capture:** The text input box containing a sample legal clause (e.g. a Governing Law or Cap On Liability provision), the active "Classify Clause" button, and the resulting prediction card displaying the predicted category and confidence tier badge (Green "High confidence").

2. **`report/figures/ui/classify_document.png`**
   - **View:** Multi-Page PDF Document Ingestion.
   - **What to capture:** The drag-and-drop file upload zone with a completed PDF contract upload, the extraction progress indicator, and the resulting paginated table displaying segmented clauses with their respective predicted categories.

3. **`report/figures/ui/search_results.png`**
   - **View:** Intelligent Semantic Search Console.
   - **What to capture:** The search bar with an active query (e.g., `"limitation of liability"` or `"termination for convenience"`), selected category filter chips, and the ranked list of retrieved clause cards showing similarity scores.

4. **`report/figures/ui/dark_mode.png`**
   - **View:** Dark Theme Aesthetic.
   - **What to capture:** The application interface with dark mode toggled on, illustrating the high-contrast slate background and accessible typography.

*(Optional supplemental UI screenshots)*:
- `report/figures/ui/mobile_view.png`: View of the responsive interface on a mobile viewport width ($\le 640\text{ px}$).
- `report/figures/ui/offline_banner.png`: View of the network status indicator when disconnected from the backend.

> **Note:** Once you save these PNG images into `report/figures/ui/`, re-running tectonic or recompiling on Overleaf will automatically substitute the placeholders with your actual application screenshots without modifying any LaTeX code!

---

## 2. Setting Up and Compiling on Overleaf

The `report/` folder and `ClauseIQ_Report.zip` are structured to be 100% Overleaf-ready:

1. Log into your Overleaf account at [https://www.overleaf.com](https://www.overleaf.com).
2. Click **New Project** $\rightarrow$ **Upload Project**.
3. Select and upload **`ClauseIQ_Report.zip`** (generated in the root of the repository).
4. Verify project settings:
   - Click the **Menu** icon in the top left corner of the Overleaf editor.
   - **Compiler:** Set to **pdfLaTeX** (default and recommended).
   - **Main Document:** Ensure `main.tex` is selected.
5. Click the green **Recompile** button.

---

## 3. Optional: Using Literal "Times New Roman" Font via XeLaTeX

By default, `main.tex` uses the standard LaTeX `mathptmx` package, which provides a Times New Roman equivalent font that compiles out-of-the-box on pdfLaTeX, Tectonic, and Overleaf without requiring local operating system font installations.

If your institution explicitly requires the literal proprietary Microsoft "Times New Roman" font file:
1. In Overleaf, open the **Menu** (top left) and change the **Compiler** from `pdfLaTeX` to **XeLaTeX**.
2. In `report/main.tex`, comment out:
   ```latex
   %\usepackage[utf8]{inputenc}
   %\usepackage[T1]{fontenc}
   %\usepackage{mathptmx}
   ```
3. Add the fontspec declarations:
   ```latex
   \usepackage{fontspec}
   \setmainfont{Times New Roman}
   ```
4. Recompile with XeLaTeX.

---

## 4. Unverified Claims / College-Specific Customization

All quantitative statements, class counts, and model metrics in this report were verified against the ClauseIQ repository and dataset. The following college-specific pages are intentionally excluded from this report because your institution provides standardized templates for them:
- College Title Cover Page
- Certificate of Authenticity / Guide Approval Certificate
- Declaration of Authorship
- Acknowledgements Page
- College Abstract Sheet
- Table of Contents, List of Tables, and List of Figures (the college usually requests their standard front-matter formatting).

The document is set up to begin directly at Arabic Page 1 on Chapter 1 (\textit{Introduction}).
